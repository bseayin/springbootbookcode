<template>
	<view>
		<view class="uni-form-item uni-column">
			<view class="title">英汉：</view>
			<input class="uni-input" name="input" placeholder="请入需要查询的单词" />
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
